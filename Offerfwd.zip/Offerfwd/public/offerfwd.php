<?php
/**
 * Plugin Name: Offerfwd
 * Version: 1.0.0
 * Plugin URI: https://conx.opt-in.net
 * Description: Publisher Integration - Opt-In Ad Monetization
 * Author: Opt-Intelligence
 * Requires at least: 3.0
 * Tested up to: 5.6
 *
 * Text Domain: offerfwd
 * Domain Path: /lang/
 *
 * @package WordPress
 * @author Opt-Intelligence
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load plugin class files.
require_once 'includes/class-offerfwd.php';
require_once 'includes/class-offerfwd-loader.php';
require_once 'includes/class-offerfwd-deactivator.php';
require_once 'includes/class-offerfwd-i18n.php';
require_once 'includes/class-offerfwd-activator.php';


function joix(){

ob_start();

$jurl = filter_var($_REQUEST['jurl'], FILTER_SANITIZE_STRING);

echo $jurl;

$jurl = $_REQUEST['jurl'];
$email = $_REQUEST['email'];
$fname = $_REQUEST['fname'];
$lname = $_REQUEST['lname'];
$hphone = $_REQUEST['hphone'];
$pid = $_REQUEST['pid'];


	
	$src_url = "'https://adfwd.com/oi/joix.php?jurl=http://web.opt-intelligence.com/app/html/blank.html&email=".$email."&fname=".$fname."&lname=".$lname."&hphone=".$hphone."&pid=".$pid."'";

    ?>

    <iframe id="iframeOffers" src="<?php echo $src_url; ?>" width="100%" height="1000" style="border:0px;"></iframe>

    <script language="javascript">
	
	var src_x = <?php echo $src_url; ?>
	
      window.onload=setTimeout(function(){
			window.$_GET = new URLSearchParams(location.search);
			var emailGrab = $_GET.get('email');
			document.getElementById('iframeOffers').src = src_x;
      },100);
    </script>

    <?php

    return ob_get_clean();
}

add_shortcode('oix','joix');

?>